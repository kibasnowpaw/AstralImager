import os
import datetime

# Get all .ss files in the current directory
ss_files = [f for f in os.listdir() if f.endswith('.ss')]

for ss_file in ss_files:
    # Read the .ss file as a binary file
    with open(ss_file, 'rb') as file:
        ss_data = file.read()

    # Extract the range of bytes that constitutes the JPG data
    # The numbers 36 and 130 are offset values to ignore header and footer bytes
    jpg_data = ss_data[36:-130]

    # Create a new .jpg file and write the JPG data to it
    jpg_file = ss_file.replace('.ss', '.jpg')
    with open(jpg_file, 'wb') as file:
        file.write(jpg_data)

    # Get the original .ss file's timestamp
    timestamp = os.path.getmtime(ss_file)

    # Apply the original .ss file's timestamp to the new .jpg file
    os.utime(jpg_file, (timestamp, timestamp))

    print(f"Converted {ss_file} to {jpg_file}")
